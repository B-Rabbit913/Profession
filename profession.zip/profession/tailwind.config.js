/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    screen: {
      sm: '480px',
      md: '768px',
      lg: '976px',
      xl: '1440px'
    },
    extend: {
      colors: {
        neon_blue: '#4769FE',
        amethyst: '#8B74D2',
        indian_red: '#CF6060',
        white: '#FFFFFF',
        seasalt: '#FAFAFD',
        lavender: '#D4D0E7',
        davy: '#D4D0E7'
      }
    },
  },
  plugins: [],
}